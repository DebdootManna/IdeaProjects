import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Pound: ");
        int P = sc.nextInt();

        int Rs = 108*P;

        System.out.println("Rupees: " + Rs);

        System.out.println("This Practical is made by 23CS043 Debdoot Manna");
    }
}