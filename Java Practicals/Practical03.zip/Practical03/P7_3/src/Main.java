// Return Value Example
public class Main {

    public static void main(String[] args) {
        int result = multiply(6, 9);
        System.out.println("Multiplication result: " + result);

        System.out.println("This Practical is made by 23CS043 Debdoot Manna");
    }

    public static int multiply(int a, int b) {
        return a * b;
    }
}
