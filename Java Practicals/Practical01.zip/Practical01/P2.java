public class P2 {
    public static void main(String[] args) {
        int var1 = 10;
        System.out.println(var1 + " is the value of var1");

        System.out.println("This Practical is made by 23CS043 - Debdoot Manna");

    }
}