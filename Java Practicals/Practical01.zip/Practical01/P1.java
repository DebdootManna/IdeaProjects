// import java.*;

public class P1 {
    public static void main(String[] args) {
        System.out.printf("Hello and welcome!");

        System.out.println("This Practical is made by 23CS043 - Debdoot Manna");
    }
}